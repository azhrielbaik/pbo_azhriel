<p>
    Halo, <b><?php echo htmlspecialchars($username); ?></b>!
</p>
<a href="index.php">Data Barang</a> | 
<a href="tampil_customer.php">Data Customer</a> | 
<a href="tampil_supplier.php">Data Supplier</a> | 
<a href="logout.php">Logout</a>
<hr>